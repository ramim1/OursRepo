# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,requests,json,time,thread
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
import cache
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
Addon = xbmcaddon.Addon()
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
img_path=os.path.join(xbmc.translatePath("special://temp/"),'images')

#img_path=os.path.join(user_dataDir,'images')
if not os.path.exists(img_path):
     os.makedirs(img_path)
ADDON=xbmcaddon.Addon(id='plugin.video.ember')
__settings__ = ADDON
max_page=int(Addon.getSetting("max"))
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
servers_db=__PLUGIN_PATH__ + "\\resources\\servers.db"

KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
import HTMLParser
html_parser = HTMLParser.HTMLParser()
link_filepursuit=[]

reload(sys)  
sys.setdefaultencoding('utf8')
search_type=int(Addon.getSetting("type"))
if KODI_VERSION>=17:
 
  domain_s='https://'
elif KODI_VERSION<17:
  domain_s='http://'
  
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database



#response = requests.post('http://www.syedgakbar.com/projects/subtitles-translate/file-upload', headers=headers, cookies=cookies, data=data)
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png",fanart="DefaultFolder.png"):
 

          
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
          
          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })
        
          liz.setProperty("IsPlayable","false")
  
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,year=' ',season=' ',episode=' ',generes=' ',rating=' ',imdb=' ',id=' ',original_title=' '):
        
        description=html_parser.unescape(description).replace(';quot&','"')
        
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description.encode('utf8'))+"&season="+urllib.quote_plus(season)+"&rating="+str(rating)+"&imdb="+(imdb)+"&year="+str(year)+"&generes="+(generes)+"&id="+(id)+"&original_title="+(original_title)
        ok=True
        video_data={}
        video_data['title']=name
        if episode!=' ':
          video_data['mediatype']='tvshow'
          video_data['TVshowtitle']=name
          video_data['Season']=int(str(season).replace('%20','0'))
          video_data['Episode']=int(str(episode).replace('%20','0'))
        else:
           video_data['mediatype']='movies'
           video_data['TVshowtitle']=''
           video_data['tvshow']=''
           video_data['season']=0
           video_data['episode']=0
        video_data['OriginalTitle']=name
        video_data['year']=year
        video_data['genre']=generes
        video_data['rating']=str(rating)
    
        video_data['poster']=fanart
        video_data['plot']=description
        video_data['imdb']=imdb
        video_data['code']=imdb
        video_data['imdbnumber']=imdb
        
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels=video_data )
        liz.setProperty( "Fanart_Image", fanart )
        art = {}
        art.update({'poster': iconimage})
        liz.setArt(art)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok



def addLink( name, url,mode,isFolder, iconimage,fanart,description,data='',year=' ',season=' ',episode=' ',generes=' ',rating=' ',imdb=' ',original_title=' '):
          description=html_parser.unescape(description).replace(';quot&','"')
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&data="+str(data)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)+"&year="+str(year)+"&season="+(season)+"&episode="+(episode)+"&imdb="+(imdb)+"&original_title="+(original_title)
 
          video_data={}
          video_data['title']=name
          if episode!=' ':
              video_data['mediatype']='tvshow'
              video_data['TVshowtitle']=name
              video_data['Season']=int(str(season).replace('%20','0'))
              video_data['Episode']=int(str(episode).replace('%20','0'))
          else:
           video_data['mediatype']='movies'
           video_data['TVshowtitle']=''
           video_data['tvshow']=''
           video_data['season']=0
           video_data['episode']=0
          video_data['OriginalTitle']=name
          video_data['year']=year
          video_data['genre']=generes
          video_data['rating']=str(rating)
    
          video_data['poster']=fanart
          video_data['plot']=description
          video_data['imdb']=imdb
          video_data['code']=imdb
          video_data['imdbnumber']=imdb
         
         
          #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels=video_data)
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):
    import requests
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',

    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    '''
    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    '''
    html=requests.get(url_link,headers=headers).content
    return html
def get_filepursuit(tv_movie,original_title,name,season_n,episode_n,show_original_year):
    global link_filepursuit
    all_links=[]
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Host': 'filepursuit.com',
        'Pragma': 'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    
    if tv_movie=='tv':
      search_string=original_title.replace(' ','+')+'+'+'s'+season_n.strip()+'e'+episode_n.strip()
    else:
      search_string=original_title.replace(' ','+')+'+'+show_original_year
    match_next=['0']

    while len(match_next)>0:
    
        html=requests.get(domain_s+'filepursuit.com/search4/%s/type/video/startrow/%s'%(search_string,match_next[0]),headers=headers).content
       
        regex='data-clipboard-text="(.+?)"'
        match=re.compile(regex).findall(html)
        dbconserver = database.connect(servers_db)
        dbcurserver = dbconserver.cursor()

        
        dbcurserver.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""speed TEXT);" % 'servers')
        try:
            dbcurserver.execute("VACUUM 'AllData';")
            dbcurserver.execute("PRAGMA auto_vacuum;")
            dbcurserver.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
            dbcurserver.execute("PRAGMA temp_store=MEMORY ;")
        except:
         pass
        dbconserver.commit()
        for link in match:
            split_link=link.split('/')
            name1=split_link[len(split_link)-1].replace('.mp4','').replace('.mkv','').replace('.avi','')
            regex='//(.+?)/'
            match_s=re.compile(regex).findall(link)[0]
            dbcurserver.execute("SELECT speed FROM servers WHERE name = '%s'"%(match_s))

            match = dbcurserver.fetchone()
            ok=0
            speed=0
            color='white'
            if match!=None:
              good_s=float(Addon.getSetting("good"))/10
           
              if match[0]!='TIMEOUT' and float(match[0])<good_s:
                ok=1
                color='gold'
              if match[0]!='TIMEOUT':
                speed=round(float(match[0]),2)
              else:
                speed='TM'
            else:
               
               color='green'
               ok=1
            
            
            if 'trailer' in name1.lower():
              ok=0
            if Addon.getSetting("filter_fp")=='false':
              ok=1
            
            if ok==1:
                if "1080" in link:
                  res="1080"
                elif "720" in link:
                  res="720"
                elif "480" in link:
                  res="720"
                elif "hd" in link.lower():
                  res="HD"
                else:
                 res=' '
                f_res=fix_q(res)
                all_links.append((name1,link,'[COLOR %s]'%color+match_s+'[/COLOR]-'+str(speed),res,f_res))
                link_filepursuit=all_links
        regex='type/video/startrow/(.+?)"><strong>Next<'
        match_next=re.compile(regex).findall(html)
    return link_filepursuit
def main_menu():
    addDir3('סרטים',' ',6,'http://img.hebus.com/hebus_2012/10/07/preview/1349590502_89973.jpg','https://newevolutiondesigns.com/images/freebies/futuristic-city-wallpaper-40.jpg','סרטים')
    addDir3('סדרות',' ',7,'http://www.ubackground.com/_ph/3/805165691.jpg','http://i2.wp.com/www.alienartgallery.com/wp-content/uploads/2016/10/futuristic-city-wallpaper-preview-6.jpg?resize=800%2C450','סדרות')
    addDir3('חיפוש מקור ניגון',' ',10,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbAWW50m5Vj5hHRpgjDa5ngPJOVW9wtRClj-sHK3GYQiFdpn3l','http://coolvibe.com/wp-content/uploads/2011/06/fortune_city_2160_001.jpg','סדרות')
    
    addNolink( 'נקה זכרון מטמון', ' ',14,False, iconimage='https://im.mtv.fi/image/5734102/landscape16_9/1024/576/c6259d30670dce3feae46c7b07f96c3b/oi/kvasaari-gravitaatioaalto-musta-aukko.jpg',fanart='https://hdwallsource.com/img/2014/1/sci-fi-wallpaper-9332-9678-hd-wallpapers.jpg')
    addNolink( 'נקה זכרון תמונות', ' ',15,False, iconimage='https://img00.deviantart.net/19f1/i/2017/192/9/b/cyber_dragon_by_virgil5-d2ijfxs.jpg',fanart='http://coolvibe.com/wp-content/uploads/2013/12/Wallpaper-Jonathan-ROD-Nest.jpg')
def movies_menu():
    addDir3('כתוביות אחרונות','www',2,'https://allsizewallpapers.files.wordpress.com/2012/07/futuristic-city-wallpaper-2560x1600.jpg','https://images2.alphacoders.com/155/155240.jpg','כתוביות אחרונות')
    addDir3('כל הסרטים','movie_all',5,'http://img.hebus.com/hebus_2012/10/07/preview/1349590502_89973.jpg','http://wallvie.com/wp-content/uploads/2017/12/Hd-Sci-Fi-Wallpapers-Wallpaper-Gallery-And-Backgrounds-Images.jpg','כל הסרטים')
    addDir3('קטגוריות סרטים','movie',4,'https://wallpapershome.com/images/pages/ico_hs/14681.jpg','https://xshyfc.com/wp-content/uploads/data/2018/3/20/HD-Sci-Fi-Wallpapers-1080p-PIC-WPXH639950.jpg','קטגוריות סרטים')
    addDir3('סרטים לפי שנים','movie_year',4,'https://s1.1zoom.ru/big0/976/Rise_of_the_Tomb_Raider_506989.jpg','https://i.ytimg.com/vi/7XNgueM3qBw/maxresdefault.jpg','סרטים לפי שנים')
    addDir3('חיפוש סרט','movie_search',5,'https://www.pixelstalk.net/download.php?url=https://www.pixelstalk.net/wp-content/uploads/2016/08/Ultra-HD-4K-Robot-Image.jpg','https://images4.alphacoders.com/718/718986.jpg','חיפוש סרט')
    
def tv_menu():
    addDir3('כתוביות אחרונות','www',13,'http://media1.santabanta.com/full1/Nature/Universe/universe-5a.jpg','http://globalmedicalco.com/photos/globalmedicalco/21/104835.jpg','כתוביות אחרונות')
    addDir3('כל הסדרות','tv_all',5,'https://previews.123rf.com/images/ipopba/ipopba1512/ipopba151200061/50572152-abstract-science-circle-global-network-connection-in-hand-on-stars-at-night-background-.jpg','http://globalmedicalco.com/photos/globalmedicalco/21/104833.jpg','כל הסדרות')
    addDir3('קטגוריות סדרות','tv',4,'https://orig00.deviantart.net/5c70/f/2007/325/8/4/technology_art_by_pdl666.png','https://vignette.wikia.nocookie.net/kill-zonefanon/images/1/1c/Badass_mawlr.jpg/revision/latest?cb=20150424015512','קטגוריות סדרות')
    addDir3('סדרות לפי שנים','tv_year',4,'https://www.philosophytalk.org/sites/default/files/ubuntu-wallpaper-2.jpg','http://cdn.amreading.com/wp-content/uploads/science-fiction-hd_01002616_283.jpg','סדרות לפי שנים')
    addDir3('חיפוש סדרה','tv_search',5,'https://www.walldevil.com/wallpapers/a35/background-wallpaper-desktops-gunmetal-robot-wallpapers-desktop-images-walls.jpg','https://pm1.narvii.com/6384/cbbfbb6bbb20bafa1031467bd4cc61e47bfc51b3_hq.jpg','חיפוש סרט')
def get_movies(url):

    if url=='www':
      html=read_site_html('https://www.screwzira.com/BrowseFilms.aspx?ResultsPerPage=100&Page=1')
    else:
      html=read_site_html(url)
    regex='<ul class="subtitleItemsListContainer  ">(.+?)</ul>'
    match=re.compile(regex,re.DOTALL).findall(html)
    
    
    regex='<li>(.+?)</li>'
    match=re.compile(regex,re.DOTALL).findall(match[0])

    for item in match:
      regex='<a href="(.+?)".+?<img src="(.+?)".+?<h3>(.+?)</h3>.+?<h4>(.+?)</h4>.+?<h5.+?>(.+?)</h5>.+?<small>(.+?)<'
      match2=re.compile(regex,re.DOTALL).findall(item)
 
      
      for link,image,name,genere,plot,year in match2:
        year_f=int(filter(str.isdigit, year))
        
        addLink(name,'https://www.screwzira.com'+link,3,False,'https://www.screwzira.com'+image,'https://www.screwzira.com'+image,genere+'\n'+plot,year=year_f,generes=genere)
    regex='<a href="(.+?)">הבא<'
    match=re.compile(regex).findall(html)
    if len(match)>0:
      addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]','https://www.screwzira.com'+match[0],2,' ',' ','[COLOR aqua][I]עמוד הבא[/I][/COLOR]')
def get_tv(url):

    if url=='www':
      html=read_site_html('https://www.screwzira.com/BrowseSeries.aspx?ResultsPerPage=100&Page=1')
    else:
      html=read_site_html(url)
    regex='<ul class="subtitleItemsListContainer  ">(.+?)</ul>'
    match=re.compile(regex,re.DOTALL).findall(html)
    
    
    regex='<li>(.+?)</li>'
    match=re.compile(regex,re.DOTALL).findall(match[0])
    
    for item in match:
      regex='<a href="(.+?)".+?<img src="(.+?)".+?<h3>(.+?)</h3>.+?<h4>(.+?)</h4>.+?<p .+?>(.+?)</p>'
      match2=re.compile(regex,re.DOTALL).findall(item)
 
      
      for link,image,name,genere,plot in match2:
        regex='עונה '+'(.+?)'+'פרק '+'(.+?)$'
        match3=re.compile(regex).findall(genere)
       
        addLink(name,'https://www.screwzira.com'+link,3,False,'https://www.screwzira.com'+image,'https://www.screwzira.com'+image,genere+'\n'+plot,generes=genere,season=match3[0][0],episode=match3[0][1])
    regex='<a href="(.+?)">הבא<'
    match=re.compile(regex).findall(html)
    if len(match)>0:
      addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]','https://www.screwzira.com'+match[0],13,' ',' ','[COLOR aqua][I]עמוד הבא[/I][/COLOR]')
def fix_q(quality):
    f_q=100
    if '2160' in quality:
      f_q=1
    if '1080' in quality:
      f_q=2
    elif '720' in quality:
      f_q=3
    elif '480' in quality:
      f_q=4
    elif 'hd' in quality.lower() or 'hq' in quality.lower():
      f_q=5
    elif '360' in quality or 'sd' in quality.lower():
      f_q=6
    elif '240' in quality:
      f_q=7
    return f_q
def play_link(name,url,season,episode,plot,fanart,icon,year,imdb,original_title):
    episode=episode.strip()
    season=season.strip()
    
    regex='\((.+?)\)'
    title=re.compile(regex).findall(name)
   
    if len(title)==0:
      original_title=re.compile(regex).findall(original_title)[0]
    else:
      original_title=re.compile(regex).findall(name)[0]
    if len(episode)==1:
          episode_n="0"+episode
    else:
           episode_n=episode
    if len(season)==1:
          season_n="0"+season
    else:
          season_n=season
    if season!=None and season!="%20" and season!=" " and season!="":
          tv_movie='tv'
    else:
         tv_movie='movie'
    data_all=((tv_movie,original_title,name,season_n,episode_n,year))
 
    links=get_filepursuit(tv_movie,original_title,name,season_n,episode_n,year)
    all_name=[]
    all_link=[]
    all_server=[]
    all_quality=[]
    links=sorted(links, key=lambda x: x[4], reverse=False)
    for name2,link,server,quality,f_res in links:
           all_name.append(name2)

           all_link.append(link)
           all_server.append(server+'- [COLOR aqua]'+str(quality)+'[/COLOR]')
           all_quality.append(quality)
    all_name.append('chapi')
 
    if 'http' in url:
     #try:
         if search_type==1:
           tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
           if episode!=' ' and episode!='%20':
             url='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(imdb,tmdbKey)
           else:
             url='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(imdb,tmdbKey)
    
           imdb=requests.get(url).json()['external_ids']['imdb_id']
         else:
           html=read_site_html(url)
        
           regex='www.imdb.com/title/(.+?)"'
           
           imdb=re.compile(regex).findall(html)[0].replace('/','')
           
     #except:
     #  imdb=' '
     #  pass
    if 'tt' in imdb:
        if tv_movie=='movie':
          all_link.append('plugin://plugin.video.chappaai/movies/play/imdb/%s/library'%imdb)
        else:
          url='http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s&language=en'%imdb.replace('tt','')
          html2=requests.get(url).content
          pre_tvdb = str(html2).split('<seriesid>')
          if len(pre_tvdb) > 1:
                tvdb = str(pre_tvdb[1]).split('</seriesid>')
          
                all_link.append('plugin://plugin.video.chappaai/tv/play/%s/%s/%s/library'%(tvdb[0],season,episode))
        all_server.append('[COLOR aqua][I]פתח בצאפי[/I][/COLOR]')
        all_quality.append(' ')
    ret=xbmcgui.Dialog().select("בחר מקור", all_server)
    if ret!=-1:
        
        all_name[ret]=urllib.unquote_plus(all_name[ret])
        final_link=all_link[ret]
        
        video_data={}
        video_data['title']=all_name[ret]
        imdb=' '
   
        if episode!=' ' and episode!='' :
              video_data['mediatype']='tvshow'
              video_data['TVshowtitle']=all_name[ret]
              video_data['Season']=int(str(season).replace('%20','0'))
              video_data['Episode']=int(str(episode).replace('%20','0'))
        else:
           video_data['mediatype']='movies'
           video_data['TVshowtitle']=''
           video_data['tvshow']=''
           video_data['season']=0
           video_data['episode']=0
        video_data['OriginalTitle']=all_name[ret]
        video_data['year']=year
        video_data['poster']=fanart
        video_data['icon']=icon
        video_data['plot']=plot
        video_data['imdb']=imdb
        video_data['code']=imdb
        video_data['imdbnumber']=imdb
        
        
        listItem = xbmcgui.ListItem(video_data['title'], path=final_link) 
        listItem.setInfo(type='Video', infoLabels=video_data)


        listItem.setProperty('IsPlayable', 'true')

        
        ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    else:
      sys.exit()
def categorys(url):
    import datetime
    now = datetime.datetime.now()
    if '_year' in url:
       for i in range((now.year),1950,-1):
         if 'tv' in url:
           addDir3(str(i),'year$$$$$'+str(i)+'$$$$$tv',5,' ',' ',str(i))
         else:
           addDir3(str(i),'year$$$$$'+str(i)+'$$$$$movie',5,' ',' ',str(i))
    else:
       if search_type==0:
        html=read_site_html('https://www.screwzira.com/Search.aspx')
        regex='id="searchForm_ddl_genre"(.+?)</select>'
        match=re.compile(regex,re.DOTALL).findall(html)
        
        regex='<option value="(.+?)">(.+?)</option>'
        match2=re.compile(regex).findall(match[0])
        for option,name in match2:
          if 'tv' in url:
            addDir3(name,option+'$$$$$tv',5,' ',' ',url)
          else:
            addDir3(name,option+'$$$$$movie',5,' ',' ',url)
       else:
            if 'tv' in url:
             url_g=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
             
            else:
             url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
             
            html_g=requests.get(url_g).json()
            genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                if i['name'] is not None])

            for items in genres_list:
             if 'tv' in url:
                addDir3(genres_list[items].encode('utf8') ,str(items)+'$$$$$tv',5,' ',' ',url)
             else:
                addDir3(genres_list[items].encode('utf8') ,str(items)+'$$$$$movie',5,' ',' ',url)
def get_images(threadName,all_images):
        import urllib
       
        for items in all_images:
            tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
            url='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(items,tmdbKey)
            data=requests.get(url).json()

            if 'backdrop_path' in data:
                 if data['backdrop_path']==None:
                  fan=' '
                 else:
                  fan=domain_s+'image.tmdb.org/t/p/original/'+data['backdrop_path']
            
            if fan!=' ':
             
              img_item=os.path.join(img_path,items+".jpg")
              if not os.path.exists(img_item):
 
                urllib.urlretrieve(fan, img_item)
def ClearCache():
    from storage import Storage
    cache.clear(['cookies', 'pages'])
    Storage.open("parsers").clear()
    storage_path = os.path.join(xbmc.translatePath("special://temp"), ".storage")
    if os.path.isdir(storage_path):
        for f in os.listdir(storage_path):
            if re.search('.cache', f):
                os.remove(os.path.join(storage_path, f))

    cookies_path = xbmc.translatePath("special://temp")
    if os.path.isdir(cookies_path):
        for f in os.listdir(cookies_path):
            if re.search('.jar', f):
                os.remove(os.path.join(cookies_path, f))
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'נוקה'.decode('utf8'))).encode('utf-8'))
def get_genere(name,url,description,season):
    url_o=url
    try:
       season=int(season)
    except:
       season='1'
    if season=='0' or season=='%20':
      season='1'
    time_to_save=int(Addon.getSetting("save_time"))*24
   
    if '_search' in url:
      all_data,all_imdb=c_get_genere(name,url,description,season,search_type)
    else:
      
      all_data,all_imdb=cache.get(c_get_genere,time_to_save,name,url,description,season,search_type, table='pages')
    
    
    if search_type==1:
      if 'tv' in url:
          for name,url,mode,icon,fan,plot,year,genere,rating,imdb,id,original_title in all_data:
            addDir3(name,url,mode,icon,fan,plot,year=year,generes=genere,rating=rating,imdb=id,id=id,original_title=original_title)
         
      else:
          for name,url,mode,icon,fan,plot,year,genere,rating,imdb,id,original_title in all_data:
            addLink(name,url,mode,False,icon,fan,plot,year=year,generes=genere,rating=rating,imdb=id,original_title=original_title)
    else:
      if 'tv' in url:
        for name,url,mode,icon,fan,plot,year,genere,rating,imdb,id,original_title in all_data:
          addDir3(name,url,mode,icon,fan,plot,year=year,generes=genere,rating=rating,imdb=imdb,id=id,original_title=name)
      else:
        for name,url,mode,icon,fan,plot,year,genere,rating,imdb,id,original_title in all_data:
          addLink(name,url,mode,False,icon,fan,plot,year=year,generes=genere,rating=rating,imdb=imdb)
    
    
    if search_type==1:
      next_season=str(int(season)+1)
    else:
       thread.start_new_thread( get_images, ("get_images",all_imdb) )
       next_season=str((int(season)+(max_page/20))+1)
    addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]',url_o,5,' ',' ','[COLOR aqua][I]עמוד הבא[/I][/COLOR]',season=next_season,original_title=name)
    
def c_get_genere(name,url,description,season,search_type_in):
    all_data=[]

    headers = {
        'Origin': 'https://www.screwzira.com',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Referer': 'https://www.screwzira.com/Search.aspx',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
    }
    if '_search' in url: 
        search_entered =''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
           search_entered = keyboard.getText()
    if 'tv' in url:
     url_g=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
     
    else:
     url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
             
    html_g=requests.get(url_g).json()
    
    if 'tv' in url:
      type='1'
      type_name='tv'
    else:
      type='0'
      type_name='movie'

    if search_type_in==1:
        all_imdb=[]
        if '_all' in url:
          
          data = 'http://api.themoviedb.org/3/%s/popular?api_key=34142515d9d23817496eeb4ff1d223d0&original_language=en&language=he&page=%s'%(type_name,season)
        elif 'year' in url:
          url2=url.split('$$$$$')[1]
          if type=='0':
            data=domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&sort_by=popularity.desc&include_adult=false&include_video=false&primary_release_year=%s&with_original_language=he|en&page=%s'%(url2,season)
          else:
            data=domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&sort_by=popularity.desc&first_air_date_year=%s&include_null_first_air_dates=false&with_original_language=en|he&page=%s'%(url2,season)
        elif '_search' in url:
           data='http://api.themoviedb.org/3/search/%s?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=%s'%(type_name,search_entered,season)
        else:
          url2=url.split('$$$$$')[0]
          
          if type=='0':
           data='http://api.themoviedb.org/3/genre/%s/movies?api_key=34142515d9d23817496eeb4ff1d223d0&sort_by=popularity.desc&language=he&page=%s'%(str(url2),season)
          else:
           data='http://api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&original_language=en&sort_by=popularity.desc&with_genres=%s&language=he&page=%s'%(str(url2),season)
        
        html=requests.get(data).json()
        for data in html['results']:
             if 'vote_average' in data:
               rating=data['vote_average']
             else:
              rating=0
             if 'first_air_date' in data:
               year=str(data['first_air_date'].split("-")[0])
             else:
                year=str(data['release_date'].split("-")[0])
             if data['overview']==None:
               plot=' '
             else:
               plot=data['overview']
             if 'title' not in data:
               new_name=data['name']
             else:
               new_name=data['title']
             f_subs=[]
             if 'original_title' in data:
               original_name=data['original_title']

               id=str(data['id'])
              
               
             else:
               original_name=data['original_name']
               id=str(data['id'])
               
             if data['poster_path']==None:
              icon=' '
             else:
               icon=data['poster_path']
             if 'backdrop_path' in data:
                 if data['backdrop_path']==None:
                  fan=' '
                 else:
                  fan=data['backdrop_path']
             else:
                fan=html['backdrop_path']
             if plot==None:
               plot=' '
             if 'http' not in fan:
               fan=domain_s+'image.tmdb.org/t/p/original/'+fan
             if 'http' not in icon:
               icon=domain_s+'image.tmdb.org/t/p/original/'+icon
             genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
             try:genere = u' / '.join([genres_list[x] for x in data['genre_ids']])
             except:genere=''
             
             if 'tv' in url:
                                  
                all_data.append ((new_name+'('+original_name+')','www',8,icon,fan,genere+'\n'+plot,year,genere,rating,id,id,new_name+'('+original_name+')'))
                #addDir3(new_name+'('+original_name+')','www',8,icon,fan,genere+'\n'+plot,year=year,generes=genere,rating=rating,imdb=id,id=id,original_title=new_name+'('+original_name+')')
             else:
                all_data.append ((new_name+'('+original_name+')',url,3,icon,fan,genere+'\n'+plot,year,genere,rating,id,id,new_name+'('+original_name+')'))
                #addLink(new_name+'('+original_name+')',url,3,False,icon,fan,genere+'\n'+plot,year=year,generes=genere,rating=rating,imdb=id,original_title=new_name+'('+original_name+')')
    else:
      all_imdb=[]

      for i in range(int(season),(int(season)+(max_page/20))+1):
        if '_all' in url:
          
          data = '{"request":{"FilmName":"","Actors":[],"Studios":[],"Directors":[],"Genres":[],"Countries":[],"Languages":[],"Year":"","Rating":[],"Page":%s,"SearchType":"%s"}}'%(str(i),type)
        elif 'year' in url:
          url2=url.split('$$$$$')[1]
          data = '{"request":{"FilmName":"","Actors":[],"Studios":[],"Directors":[],"Genres":[],"Countries":[],"Languages":[],"Year":"%s","Rating":[],"Page":%s,"SearchType":"%s"}}'%(url2,str(i),type)
        elif '_search' in url:
          data = '{"request":{"FilmName":"%s","Actors":[],"Studios":[],"Directors":[],"Genres":[],"Countries":[],"Languages":[],"Year":"","Rating":[],"Page":%s,"SearchType":"%s"}}'%(search_entered,str(i),type)
        else:
          url2=url.split('$$$$$')[0]
          data = '{"request":{"FilmName":"","Actors":[],"Studios":[],"Directors":[],"Genres":["%s"],"Countries":[],"Languages":[],"Year":"","Rating":[],"Page":%s,"SearchType":"%s"}}'%(url2,str(i),type)
        
        response = requests.post('https://www.screwzira.com/Services/ContentProvider.svc/SearchPage_search', headers=headers, data=data).json()
  
       
        for item in json.loads(response['d'])['Films']:
          name=item['HebName']+'('+item['EngName']+')'
          year=item['ReleaseDate']
          image='https://www.screwzira.com/Content/Films/%s/Images/thumb.jpg'%item['FolderID']
          genere=item['Genres']
          plot=item['Summary']
          rating=item['Rating']
          imdbs=re.compile('www.imdb.com/title/(.+?)$').findall(item['IMDB_Link'])

          try:
            imdb=imdbs[0].replace('/','')
          except:
             imdb=None
          if genere==None:
             genere=' '
          if plot==None:
             plot=' '
          if rating==None:
             rating=' '
          if imdb==None:
             
             imdb=' '
          if year==None:
             year=' '
          if len(imdb)>2:
            all_imdb.append(imdb)
            
            fan=os.path.join(img_path,imdb+'.jpg')
            
          else:
            
            fan=image
         
          if 'tv' in url:
                             
            all_data.append ((name,'https://www.screwzira.com/MovieInfo.aspx?ID=%s#'%item['ID'],8,image,fan,genere+'\n'+plot,year,genere,rating,imdb,item['ID'],name))
            #addDir3(name,'https://www.screwzira.com/MovieInfo.aspx?ID=%s#'%item['ID'],8,image,fan,genere+'\n'+plot,year=year,generes=genere,rating=rating,imdb=imdb,id=item['ID'],original_title=name)
          else:
                              
            all_data.append ((name,url,3,image,fan,genere+'\n'+plot,year,genere,rating,imdb,item['ID'],name))
            #addLink(name,url,3,False,image,fan,genere+'\n'+plot,year=year,generes=genere,rating=rating,imdb=imdb)
    return all_data,all_imdb

def get_season(name,url,season,episode,description,fanart,iconimage,year,imdb,generes,rating,id,original_title):
 
   if search_type==0:
    html=read_site_html(url)
    
    regex="var seasonsInfo = '(.+?)'"
    match=re.compile(regex).findall(html)
    data=json.loads(match[0])
    for item in data:
       addDir3('עונה '+str(item['Key']),str(item['Value']),9,iconimage,fanart,description,season=str(item['Key']),year=year,generes=generes,rating=rating,imdb=imdb,id=id,original_title=original_title)
       
       
   else:
       url2=domain_s+'api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he,en&append_to_response=external_ids'%id

       html=requests.get(url2).json()
       show_original_year=html['first_air_date'].split("-")[0]

       #tmdb data
       #headers['Authorization'] = "Bearer %s" %  str(r_json.get('token'))
       tmdbid=html['external_ids']['tvdb_id']
       if tmdbid==None:
         response2 = requests.get(domain_s+'www.thetvdb.com/?string=%s&searchseriesid=&tab=listseries&function=Search'%name).content
         
         SearchSeriesRegexPattern = 'a href=".+?tab=series.+?id=(.+?)mp'
         match=re.compile(SearchSeriesRegexPattern).findall(response2)
       
         for tmnum in match:
           tmnum=tmnum.replace("&a","")
           if len(tmnum)>0:
             tmdbid=tmnum

       response = requests.get('http://thetvdb.com/api/0629B785CE550C8D/series/%s/all/he.xml'%html['external_ids']['tvdb_id']).content
      
       attr=['Combined_season','FirstAired']
       regex='<Episode>.+?<EpisodeName>(.+?)</EpisodeName>.+?<EpisodeNumber>(.+?)</EpisodeNumber>.+?<FirstAired>(.+?)</FirstAired>.+?<SeasonNumber>(.+?)</SeasonNumber>'
       match=re.compile(regex,re.DOTALL).findall(response)
       #seasons_tvdb=parseDOM(response,'Episode', attr)
       all_season=[]
       all_season_tvdb_data=[]

       for ep_name,ep_num,aired,s_number in match:
         if s_number not in all_season:

           all_season.append(str(s_number))
           all_season_tvdb_data.append({"name":ep_name,"episode_number":ep_num,"air_date":aired,"season_number":s_number,"poster_path":iconimage})

       all_season_tmdb=[]
       for data in html['seasons']:
          all_season_tmdb.append(str(data['season_number']))
       for items_a in all_season:
         if items_a not in all_season_tmdb:
           html['seasons'].append(all_season_tvdb_data[all_season.index(items_a)])
       plot=html['overview']
       original_name=html['original_name']
       for data in html['seasons']:
       
         new_name=' עונה '.decode('utf8')+str(data['season_number'])
         if data['air_date']!=None:
             year=str(data['air_date'].split("-")[0])
         else:
           year=0
         season=str(data['season_number'])
         if data['poster_path']==None:
          icon=iconimage
         else:
           icon=data['poster_path']
         if 'backdrop_path' in data:
             if data['backdrop_path']==None:
              fan=fanart
             else:
              fan=data['backdrop_path']
         else:
            fan=html['backdrop_path']
         if plot==None:
           plot=' '
         if fan==None:
           fan=fanart
         if 'http' not in fan:
           fan=domain_s+'image.tmdb.org/t/p/original/'+fan
         if 'http' not in icon:
           icon=domain_s+'image.tmdb.org/t/p/original/'+icon
     
         addDir3(new_name,url,9,icon,fan,plot,original_title=original_title,id=id,season=season,imdb=str(id),year=show_original_year)
def get_episode(name,url,season,episode,description,fanart,iconimage,year,imdb,generes,rating,id,original_title):
   if search_type==0:
    headers = {
        'Origin': 'https://www.screwzira.com',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Referer': 'https://www.screwzira.com/MovieInfo.aspx?ID='+id,
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
    }

    data = '{"seasonID":"%s"}'%url

    response = requests.post('https://www.screwzira.com/Services/ContentProvider.svc/GetEpisodesForSeason', headers=headers, data=data).json()
    for item in json.loads(response['d'])['Episodes']:

       addLink(str(item['Key']),str(item['Value']),3,False,iconimage,fanart,description,year=year,generes=generes,rating=rating,imdb=imdb,season=season,episode=str(item['Key']).replace('פרק','').replace(' ',''),original_title=original_title)

   else:
       import _strptime
       url=domain_s+'api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%(id,season)

       html=requests.get(url).json()
       #tmdb data
       if html['episodes'][0]['name']=='':
         url=domain_s+'api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=eng'%(id,season)
         html=requests.get(url).json()
       response = requests.get('http://thetvdb.com/api/0629B785CE550C8D/series/%s/all/he.xml'%imdb).content
       
       attr=['Combined_season','FirstAired']
       regex='<Episode>.+?<EpisodeName>(.+?)</EpisodeName>.+?<EpisodeNumber>(.+?)</EpisodeNumber>.+?<FirstAired>(.+?)</FirstAired>.+?<Overview>(.+?)</Overview>.+?<SeasonNumber>(.+?)</SeasonNumber>'
       match=re.compile(regex,re.DOTALL).findall(response)
       regex_eng='<slug>(.+?)</slug>'
       match_eng=re.compile(regex_eng).findall(response)
       
       eng_name=name
       if len (match_eng)>0:
         eng_name=match_eng[0]

       #seasons_tvdb=parseDOM(response,'Episode', attr)

       all_episodes=[]
       all_season_tvdb_data=[]
       image2=' '
       for ep_name,ep_num,aired,overview,s_number in match:
         
         image2=fanart
         if s_number==season:
             if ep_num not in all_episodes:
               
               all_episodes.append(str(ep_num))
               all_season_tvdb_data.append({"name":ep_name,"episode_number":ep_num,"air_date":aired,"overview":overview,"season_number":s_number,"still_path":iconimage,"poster_path":image2})

       all_episodes_tmdb=[]

       if 'episodes' not in html:
         html['episodes']=[]
         html['poster_path']=fanart
       for data in html['episodes']:
          all_episodes_tmdb.append(str(data['episode_number']))
       for items_a in all_episodes:
         if items_a not in all_episodes_tmdb:
           html['episodes'].append(all_season_tvdb_data[all_episodes.index(items_a)])

       original_name=original_title
       if Addon.getSetting("dp")=='true' and (Addon.getSetting("disapear")=='true' or Addon.getSetting("check_subs")=='true'):
                dp = xbmcgui.DialogProgress()
                dp.create("טוען סרטים", "אנא המתן", '')
                dp.update(0)
       xxx=0
       start_time = time.time()
       from datetime import datetime
       for data in html['episodes']:
         plot=data['overview']
         new_name=str(data['episode_number'])+" . "+data['name']
         air_date=''
         if 'air_date' in data:
           if data['air_date']!=None:
             
             year=str(data['air_date'].split("-")[0])
           else:
             year=0
         else:
           year=0
         
         if data['still_path']!=None:
           if 'https' not in data['still_path']:
             image=domain_s+'image.tmdb.org/t/p/original/'+data['still_path']
           else:
             image=data['still_path']
           
         elif html['poster_path']!=None:
          if 'https' not in html['poster_path']:
           image=domain_s+'image.tmdb.org/t/p/original/'+html['poster_path']
          else:
             image=html['poster_path']
         else:
           image=fanart
         if html['poster_path']!=None:
          if 'https' not in html['poster_path']:
           icon=domain_s+'image.tmdb.org/t/p/original/'+html['poster_path']
          else:
            icon=html['poster_path']
         else:
           icon=iconimage
         #if image2==fanart:
         #  icon=iconimage
          
         #  image=fanart
         color2='white'
         datea=''
         if 'air_date' in data:
           try:
               
               datea='[COLOR aqua]'+str(time.strptime(data['air_date'], '%Y-%m-%d'))+'[/COLOR]\n'
               
               a=(time.strptime(data['air_date'], '%Y-%m-%d'))
               b=time.strptime(str(time.strftime('%Y-%m-%d')), '%Y-%m-%d')
               
           
               if a>b:
                 color2='red'
               else:
                 
                 color2='white'
               datea='[COLOR aqua]'+' שודר בתאריך '+time.strftime( "%d-%m-%Y",a) + '[/COLOR]\n'
           except:
                 a=''
                 datea=''
                 color2='red'
           f_subs=[]
           
         
        

       
         color=color2
         if season!=None and season!="%20":
            tv_movie='tv'
         else:
           tv_movie='movie'
        
         elapsed_time = time.time() - start_time
         if (Addon.getSetting("check_subs")=='true'  or Addon.getSetting("disapear")=='true') and Addon.getSetting("dp")=='true':
            dp.update(int(((xxx* 100.0)/(len(html['episodes']))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'[COLOR'+color+']'+new_name+'[/COLOR]')
         xxx=xxx+1
         if  Addon.getSetting("disapear")=='true' and color=='red':
            a=1
         else:
           
           #addDir3( '[COLOR %s]'%color+new_name+'[/COLOR]', url,4, icon,image,datea+plot,data=year,original_title=original_name,id=id,season=season,episode=data['episode_number'],eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr)
           addLink('[COLOR %s]'%color+new_name+'[/COLOR]',url,3,False,icon,image,datea+plot,year=year,generes=generes,rating=rating,imdb=imdb,season=season,episode=str(data['episode_number']),original_title=original_name)
         xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_EPISODE)
def search_source():
    search_entered =''
  
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    dbconserver = database.connect(servers_db)
    dbcurserver = dbconserver.cursor()

    
    dbcurserver.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""speed TEXT);" % 'servers')
    try:
        dbcurserver.execute("VACUUM 'AllData';")
        dbcurserver.execute("PRAGMA auto_vacuum;")
        dbcurserver.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
        dbcurserver.execute("PRAGMA temp_store=MEMORY ;")
    except:
     pass
    dbconserver.commit()
    
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           match_next=['0']
           while len(match_next)>0:
               headers = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'Host': 'filepursuit.com',
                    'Pragma': 'no-cache',
                    'Upgrade-Insecure-Requests': '1',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
               }
               html=requests.get(domain_s+'filepursuit.com/search4/%s/type/video/startrow/%s'%(search_entered,match_next[0]),headers=headers).content
           
               regex='data-clipboard-text="(.+?)"'
               match=re.compile(regex).findall(html)
               if len(match)>0:
                
                for link in match:
                 res=' '
                 split_link=link.split('/')
                 name1=split_link[len(split_link)-1].replace('.mp4','').replace('.mkv','').replace('.avi','').replace("%20"," ")
                 regex='//(.+?)/'
                 match_s=re.compile(regex).findall(link)[0]
                 dbcurserver.execute("SELECT speed FROM servers WHERE name = '%s'"%(match_s))

                 match = dbcurserver.fetchone()
                 ok=0
                
                 if match!=None:
          
                  if match[0]!='TIMEOUT' and float(match[0])<0.6:
                    ok=1
                 else:
      
                   ok=1
                 if 'trailer' in name1.lower():
                  ok=0
                 
                 if ok==1:
                    if "1080" in link:
                      res="1080"
                    elif "720" in link:
                      res="720"
                    elif "480" in link:
                      res="720"
                    elif "hd" in link.lower():
                      res="HD"
                    else:
                     res=' '
                    addLink(name1+'('+name1+')',link,11,False,' ',' ',match_s+'\n'+res)
                    regex='type/video/startrow/(.+?)"><strong>Next<'
                    match_next=re.compile(regex).findall(html)
def direct_play(name,url):
    listItem = xbmcgui.ListItem(name, path=url) 
    listItem.setInfo(type='Video', infoLabels={'title':name})


    listItem.setProperty('IsPlayable', 'true')

    
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)


params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
season='0'
episode='0'
year='0'
rating='0'
original_title=' '
generes=' '
imdb=' '
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        season=urllib.unquote_plus(params["season"])
except:
        pass
try:        
        episode=(params["episode"])
except:
        pass

try:        
        year=(params["year"])
except:
        pass
try:        
        imdb=(params["imdb"])
except:
        pass
try:       
        generes=urllib.unquote_plus(params["generes"])
except:
        pass
try:        
        rating=(params["rating"])
except:
        pass
try:        
        id=(params["id"])
except:
        pass
try:        
        original_title=(params["original_title"])
except:
        pass

if episode=='+':
  episode=' '
if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
       get_movies(url)
elif mode==3:
       play_link(name,url,season,episode,description,fanart,iconimage,year,imdb,original_title)
elif mode==4:
       categorys(url)
elif mode==5:
       get_genere(name,url,description,season)
elif mode==6:
       movies_menu()
elif mode==7:
       tv_menu()
elif mode==8:
       get_season(name,url,season,episode,description,fanart,iconimage,year,imdb,generes,rating,id,original_title)
elif mode==9:
       get_episode(name,url,season,episode,description,fanart,iconimage,year,imdb,generes,rating,id,original_title)
elif mode==10:
       search_source()
elif mode==11:
       direct_play(name,url)
elif mode==12:
       search(url)
elif mode==13:
       get_tv(url)
elif mode==14:
       ClearCache()
elif mode==15:
      try:
       import shutil
       
       shutil.rmtree(img_path)
       xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'נוקה'.decode('utf8'))).encode('utf-8'))
      except:
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'שגיאה לא ניתן למחוק כרגע נסה מאוחר יותר'.decode('utf8'))).encode('utf-8'))
        pass
if mode!=None:
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

